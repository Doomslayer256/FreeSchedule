#include "FreeSchedule.h"
#include <string.h>

FreeSchedule::FreeSchedule() {
  taskCount = 0;
}

int FreeSchedule::addTask(const char* name, TaskFunction func, unsigned long interval) {
  if (taskCount >= FS_MAX_TASKS) return -1;
  strncpy(taskNames[taskCount], name, FS_NAME_LEN - 1);
  taskNames[taskCount][FS_NAME_LEN - 1] = '\\0'; // Null-terminate
  tasks[taskCount] = func;
  intervals[taskCount] = interval;
  lastRun[taskCount] = millis();
  enabled[taskCount] = true;
  taskCount++;
  return taskCount - 1;
}

bool FreeSchedule::removeTask(const char* name) {
  int idx = findTaskIndex(name);
  if (idx == -1) return false;
  for (int i = idx; i < taskCount - 1; i++) {
    strncpy(taskNames[i], taskNames[i + 1], FS_NAME_LEN);
    tasks[i] = tasks[i + 1];
    intervals[i] = intervals[i + 1];
    lastRun[i] = lastRun[i + 1];
    enabled[i] = enabled[i + 1];
  }
  taskCount--;
  return true;
}

bool FreeSchedule::enableTask(const char* name) {
  int idx = findTaskIndex(name);
  if (idx == -1) return false;
  enabled[idx] = true;
  return true;
}

bool FreeSchedule::disableTask(const char* name) {
  int idx = findTaskIndex(name);
  if (idx == -1) return false;
  enabled[idx] = false;
  return true;
}

bool FreeSchedule::killTask(const char* name) {
  int idx = findTaskIndex(name);
  if (idx == -1) return false;
  
  // Kill the task by removing it
  return removeTask(name);
}

int FreeSchedule::findTaskIndex(const char* name) {
  for (int i = 0; i < taskCount; i++) {
    if (strncmp(taskNames[i], name, FS_NAME_LEN) == 0) {
      return i;
    }
  }
  return -1;
}

void FreeSchedule::run() {
  unsigned long now = millis();
  for (int i = 0; i < taskCount; i++) {
    if (!enabled[i]) continue;
    if (now - lastRun[i] >= intervals[i]) {
      lastRun[i] = now;
      tasks[i]();
    }
  }
}

#ifndef FREESCHEDULE_H
#define FREESCHEDULE_H

#include <Arduino.h>

#define FS_MAX_TASKS 10
#define FS_NAME_LEN 16

class FreeSchedule {
  public:
    typedef void (*TaskFunction)();

    FreeSchedule();
    int addTask(const char* name, TaskFunction func, unsigned long interval);
    bool removeTask(const char* name);
    bool enableTask(const char* name);
    bool disableTask(const char* name);
    bool killTask(const char* name);
    void run();

  private:
    TaskFunction tasks[FS_MAX_TASKS];
    unsigned long intervals[FS_MAX_TASKS];
    unsigned long lastRun[FS_MAX_TASKS];
    char taskNames[FS_MAX_TASKS][FS_NAME_LEN];
    bool enabled[FS_MAX_TASKS];
    int taskCount;

    int findTaskIndex(const char* name);
};

#endif
